import tensorflow as tf
import numpy as np
from tensorflow.keras.utils import load_img, img_to_array
import os

def convert_model_if_needed(model_path):
    """Convierte el modelo a un formato compatible si es necesario."""
    try:
        # Intenta cargar el modelo directamente
        model = tf.keras.models.load_model(model_path)
        return model
    except Exception as e:
        print(f"El modelo no es compatible: {e}")
        print("Intentando convertir el modelo...")

        # Convierte el modelo a un formato más reciente
        try:
            model = tf.keras.models.load_model(model_path, compile=False)
            converted_model_path = 'converted_model/'
            model.save(converted_model_path)
            print("Modelo convertido y guardado como 'converted_model/'.")
            return tf.keras.models.load_model(converted_model_path)
        except Exception as convert_error:
            raise RuntimeError(f"No se pudo convertir el modelo: {convert_error}")

def get_class(model_path, labels_path, image_path):
    try:
        # Cargar el modelo (con conversión si es necesario)
        model = convert_model_if_needed(model_path)

        # Cargar las etiquetas
        with open(labels_path, 'r') as f:
            labels = [line.strip() for line in f.readlines()]

        # Cargar y preprocesar la imagen
        image = load_img(image_path, target_size=(224, 224))  # Ajusta al tamaño del modelo
        image_array = img_to_array(image) / 255.0
        image_array = np.expand_dims(image_array, axis=0)

        # Realizar la predicción
        predictions = model.predict(image_array)
        predicted_index = np.argmax(predictions)
        predicted_label = labels[predicted_index]

        return predicted_label
    except Exception as e:
        return f"Ocurrió un error al clasificar la imagen: {e}"

# Para probar la conversión fuera del bot, puedes usar este bloque:
if __name__ == "__main__":
    # Ruta del modelo, etiquetas y una imagen de prueba
    model_path = "keras_model.h5"
    labels_path = "labels.txt"
    image_path = ""

    if not os.path.exists(model_path):
        print(f"El modelo '{model_path}' no existe.")
    elif not os.path.exists(labels_path):
        print(f"El archivo de etiquetas '{labels_path}' no existe.")
    elif not os.path.exists(image_path):
        print(f"La imagen de prueba '{image_path}' no existe.")
    else:
        result = get_class(model_path, labels_path, image_path)
        print(f"Resultado de la clasificación: {result}")
