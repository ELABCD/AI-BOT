import discord
from discord.ext import commands
from model import get_class  # Importa la función de clasificación
import os

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix='/', intents=intents)

# Carpeta para guardar imágenes
IMAGES_FOLDER = './imagenes'

if not os.path.exists(IMAGES_FOLDER):
    os.makedirs(IMAGES_FOLDER)

# Estado del bot
is_active = False

@bot.event
async def on_ready():
    print(f'Has iniciado como: {bot.user}')

# Comando para activar el bot
@bot.command('Activar')
async def activar(ctx):
    global is_active
    if is_active:
        await ctx.send("El bot ya está activado.")
        return
    is_active = True
    await ctx.send("El bot ya esta activado! 😀")

# Comando para desactivar el bot
@bot.command('Desactivar')
async def desactivar(ctx):
    global is_active
    if not is_active:
        await ctx.send("El bot ya está desactivado. 😟")
        return
    is_active = False
    await ctx.send("El bot ya esta desactivado! ")

# Comando para subir una imagen
@bot.command('subirimagen')
async def subir_imagen(ctx):
    if not is_active:
        await ctx.send("El bot no está activado. Usa /Activar para activarlo.")
        return
    
    if ctx.message.attachments:
        for attachment in ctx.message.attachments:
            file_name = attachment.filename
            file_path = os.path.join(IMAGES_FOLDER, file_name)
            await attachment.save(file_path)
            try:
                # Clasificación de la imagen con el modelo
                classification = get_class(model_path="./keras_model.h5", labels_path="labels.txt", image_path=file_path)
                await ctx.send(f"Imagen subida y guardada como: {file_name}. Clasificación: {classification}")
            except Exception as e:
                await ctx.send(f"Ocurrió un error al clasificar la imagen: {e}")
    else:
        await ctx.send("No subiste ninguna imagen. ¡Intenta nuevamente!")

# Comando para ver las imágenes guardadas
@bot.command('check')
async def check(ctx):
    if not os.path.exists(IMAGES_FOLDER) or not os.listdir(IMAGES_FOLDER):
        await ctx.send("No hay imágenes guardadas aún.")
        return
    
    saved_images = os.listdir(IMAGES_FOLDER)
    await ctx.send(f"Imágenes guardadas: {', '.join(saved_images)}")


bot.run("MTI2NjUwNzQ1OTYwMjgwODg3Mg.GZO_9y.gcxiiBlpxpNu7k9xg7qpQYkNMh6e7zJlYIMJJs")
